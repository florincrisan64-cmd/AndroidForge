package ro.asistentai.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private lateinit var tts: TextToSpeech
    private var elevenPlayer: android.media.MediaPlayer? = null
    private var filePathCallback: android.webkit.ValueCallback<Array<android.net.Uri>>? = null
    private var cameraUri: android.net.Uri? = null
    private val allowedHosts = setOf("api.groq.com", "api.mistral.ai", "api.cerebras.ai")

    private val chooserLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val cb = filePathCallback
        filePathCallback = null
        if (cb != null) {
            var uris: Array<android.net.Uri>? = null
            if (result.resultCode == RESULT_OK) {
                val data = result.data
                val hasData = data != null && (data.data != null || data.clipData != null)
                if (hasData) {
                    uris = android.webkit.WebChromeClient.FileChooserParams.parseResult(result.resultCode, data)
                } else {
                    val cam = cameraUri
                    if (cam != null) uris = arrayOf(cam)
                }
            }
            cb.onReceiveValue(uris)
        }
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startVoiceRecognizer()
    }

    private val voiceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return@registerForActivityResult
            val escaped = text.replace("\\", "\\\\").replace("'", "\\'")
            webView.evaluateJavascript("document.getElementById('input').value='$escaped';", null)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.webview)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == "appassets.androidplatform.net") return false
                openExternal(request.url.toString())
                return true
            }
        }
        webView.addJavascriptInterface(NativeBridge(), "AndroidNative")
        clearCameraCache()
        webView.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: android.webkit.ValueCallback<Array<android.net.Uri>>,
                params: android.webkit.WebChromeClient.FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                cameraUri = null
                try {
                    if (params.isCaptureEnabled) {
                        val dir = java.io.File(cacheDir, "camera")
                        dir.mkdirs()
                        val photo = java.io.File.createTempFile("photo_", ".jpg", dir)
                        val uri = androidx.core.content.FileProvider.getUriForFile(this@MainActivity, packageName + ".fileprovider", photo)
                        cameraUri = uri
                        val cam = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
                        cam.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, uri)
                        cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        chooserLauncher.launch(cam)
                    } else {
                        val types = params.acceptTypes.filter { it.contains("/") }
                        val pick = Intent(Intent.ACTION_GET_CONTENT)
                        pick.addCategory(Intent.CATEGORY_OPENABLE)
                        pick.type = if (types.size == 1) types[0] else "*/*"
                        if (types.size > 1) pick.putExtra(Intent.EXTRA_MIME_TYPES, types.toTypedArray())
                        pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.mode == android.webkit.WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE)
                        chooserLauncher.launch(Intent.createChooser(pick, "Alege"))
                    }
                } catch (e: Exception) {
                    filePathCallback = null
                    callback.onReceiveValue(null)
                    showStatus("Nu am putut deschide selectorul de fișiere sau camera.")
                }
                return true
            }
        }
        tts = TextToSpeech(this, this)
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale("ro", "RO")
    }

    inner class NativeBridge {
        @JavascriptInterface fun speak(text: String) {
            runOnUiThread { tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "asistent-ai") }
        }
        @JavascriptInterface fun openUrl(url: String) {
            runOnUiThread { openExternal(url) }
        }
        @JavascriptInterface fun share(title: String, text: String) {
            runOnUiThread {
                try {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, title)
                        putExtra(Intent.EXTRA_TEXT, text)
                    }
                    startActivity(Intent.createChooser(send, title))
                } catch (e: Exception) {
                    webView.evaluateJavascript("setStatus('Partajarea nu a reușit. Încearcă butonul Copiază.')", null)
                }
            }
        }
        @JavascriptInterface fun openIn(pkg: String, label: String, text: String) {
            runOnUiThread {
                try {
                    val clipboard = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Asistent AI", text))
                } catch (e: Exception) { }
                val direct = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                    setPackage(pkg)
                }
                try {
                    startActivity(direct)
                    showStatus("Trimis către " + label + ". Dacă nu apare întrebarea, e copiată: lipește-o.")
                } catch (e: Exception) {
                    try {
                        val generic = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, text)
                        }
                        startActivity(Intent.createChooser(generic, label))
                        showStatus(label + " nu a primit textul direct. Întrebarea e copiată: deschide " + label + " și lipește-o.")
                    } catch (e2: Exception) {
                        showStatus("Nu am putut deschide " + label + ". Întrebarea e copiată.")
                    }
                }
            }
        }
        @JavascriptInterface fun setTheme(dark: Boolean) {
            runOnUiThread {
                window.statusBarColor = if (dark) 0xFF202020.toInt() else 0xFFF2F2F2.toInt()
                window.navigationBarColor = if (dark) 0xFF111111.toInt() else 0xFFFFFFFF.toInt()
                val controller = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
                controller.isAppearanceLightStatusBars = !dark
                controller.isAppearanceLightNavigationBars = !dark
            }
        }
        @JavascriptInterface fun httpPost(id: String, url: String, headersJson: String, body: String) {
            val safeId = id.replace(Regex("[^A-Za-z0-9_]"), "")
            val host = try { android.net.Uri.parse(url).host } catch (e: Exception) { null }
            if (!url.startsWith("https://") || host == null || !allowedHosts.contains(host)) {
                jsCall("window.onHttp('" + safeId + "',0,'" + b64("Adresă nepermisă.") + "')")
                return
            }
            Thread {
                try {
                    val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 15000
                    conn.readTimeout = 90000
                    conn.doOutput = true
                    val headers = org.json.JSONObject(headersJson)
                    val names = headers.keys()
                    while (names.hasNext()) {
                        val name = names.next()
                        conn.setRequestProperty(name, headers.getString(name))
                    }
                    conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                    conn.disconnect()
                    jsCall("window.onHttp('" + safeId + "'," + code + ",'" + b64(text) + "')")
                } catch (e: Exception) {
                    jsCall("window.onHttp('" + safeId + "',0,'" + b64(e.message ?: "eroare de rețea") + "')")
                }
            }.start()
        }
        @JavascriptInterface fun stopSpeech() {
            runOnUiThread {
                stopEleven()
                if (::tts.isInitialized) tts.stop()
            }
        }
        @JavascriptInterface fun elevenVoices(key: String) {
            Thread {
                try {
                    val conn = java.net.URL("https://api.elevenlabs.io/v2/voices?page_size=100").openConnection() as java.net.HttpURLConnection
                    conn.requestMethod = "GET"
                    conn.connectTimeout = 15000
                    conn.readTimeout = 20000
                    conn.setRequestProperty("xi-api-key", key)
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                    conn.disconnect()
                    if (code in 200..299) {
                        val compact = org.json.JSONArray()
                        val arr = org.json.JSONObject(body).optJSONArray("voices")
                        if (arr != null) {
                            for (i in 0 until arr.length()) {
                                val v = arr.getJSONObject(i)
                                val labels = v.optJSONObject("labels")
                                val lb = org.json.JSONObject()
                                for (field in arrayOf("gender", "accent", "use_case", "descriptive")) {
                                    lb.put(field, if (labels == null || labels.isNull(field)) "" else labels.optString(field, ""))
                                }
                                val o = org.json.JSONObject()
                                o.put("voice_id", v.optString("voice_id", ""))
                                o.put("name", v.optString("name", ""))
                                o.put("category", v.optString("category", ""))
                                o.put("labels", lb)
                                compact.put(o)
                            }
                        }
                        jsCall("window.onElevenVoices(200,'" + b64(org.json.JSONObject().put("voices", compact).toString()) + "')")
                    } else {
                        jsCall("window.onElevenVoices(" + code + ",'" + b64(body) + "')")
                    }
                } catch (e: Exception) {
                    jsCall("window.onElevenVoices(0,'" + b64(e.message ?: "eroare de rețea") + "')")
                }
            }.start()
        }
        @JavascriptInterface fun elevenSpeak(key: String, voiceId: String, modelId: String, lang: String, speed: Double, text: String) {
            runOnUiThread {
                stopEleven()
                if (::tts.isInitialized) tts.stop()
            }
            Thread {
                try {
                    val payload = org.json.JSONObject()
                    payload.put("text", text)
                    payload.put("model_id", modelId)
                    if (lang.isNotEmpty()) payload.put("language_code", lang)
                    payload.put("voice_settings", org.json.JSONObject().put("speed", speed))
                    val conn = java.net.URL("https://api.elevenlabs.io/v1/text-to-speech/" + java.net.URLEncoder.encode(voiceId, "UTF-8")).openConnection() as java.net.HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 15000
                    conn.readTimeout = 60000
                    conn.doOutput = true
                    conn.setRequestProperty("xi-api-key", key)
                    conn.setRequestProperty("Content-Type", "application/json")
                    conn.setRequestProperty("Accept", "audio/mpeg")
                    conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    if (code in 200..299) {
                        val file = java.io.File(cacheDir, "eleven_tts.mp3")
                        conn.inputStream.use { input -> file.outputStream().use { out -> input.copyTo(out) } }
                        conn.disconnect()
                        runOnUiThread { playEleven(file.absolutePath) }
                    } else {
                        val body = conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                        conn.disconnect()
                        jsCall("window.onElevenError(" + code + ",'" + b64(body) + "')")
                    }
                } catch (e: Exception) {
                    jsCall("window.onElevenError(0,'" + b64(e.message ?: "eroare de rețea") + "')")
                }
            }.start()
        }
        @JavascriptInterface fun startVoiceInput() {
            runOnUiThread {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) else startVoiceRecognizer()
            }
        }
    }

    private fun openExternal(url: String) {
        try {
            if (url.startsWith("http://") || url.startsWith("https://")) {
                startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
            }
        } catch (e: Exception) {
            showStatus("Nu am putut deschide linkul.")
        }
    }

    private fun showStatus(msg: String) {
        webView.evaluateJavascript("setStatus('" + msg.replace("\\", "\\\\").replace("'", "\\'") + "')", null)
    }

    private fun clearCameraCache() {
        try {
            java.io.File(cacheDir, "camera").listFiles()?.forEach { it.delete() }
        } catch (e: Exception) { }
    }

    private fun jsCall(js: String) {
        runOnUiThread { webView.evaluateJavascript(js, null) }
    }

    private fun b64(s: String): String =
        android.util.Base64.encodeToString(s.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP)

    private fun stopEleven() {
        try {
            elevenPlayer?.let {
                if (it.isPlaying) it.stop()
                it.release()
            }
        } catch (e: Exception) { }
        elevenPlayer = null
    }

    private fun playEleven(path: String) {
        try {
            stopEleven()
            val mp = android.media.MediaPlayer()
            mp.setAudioAttributes(
                android.media.AudioAttributes.Builder()
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH)
                    .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            mp.setDataSource(path)
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener {
                it.release()
                if (elevenPlayer === it) elevenPlayer = null
                jsCall("window.onElevenDone && window.onElevenDone()")
            }
            mp.setOnErrorListener { p, _, _ ->
                p.release()
                if (elevenPlayer === p) elevenPlayer = null
                jsCall("window.onElevenError(-1,'" + b64("Redarea audio a eșuat.") + "')")
                true
            }
            elevenPlayer = mp
            mp.prepareAsync()
        } catch (e: Exception) {
            jsCall("window.onElevenError(-1,'" + b64(e.message ?: "Redarea audio a eșuat.") + "')")
        }
    }

    private fun startVoiceRecognizer() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ro-RO")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Vorbește...")
        }
        voiceLauncher.launch(intent)
    }

    override fun onDestroy() {
        stopEleven()
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
