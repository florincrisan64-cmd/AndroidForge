package ro.asistentai.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private lateinit var tts: TextToSpeech

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startVoiceRecognizer()
    }

    private val voiceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return@registerForActivityResult
            val escaped = text.replace("\\", "\\\\").replace("'", "\\'")
            webView.evaluateJavascript("document.getElementById('input').value='$escaped';", null)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.webview)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
        }
        webView.addJavascriptInterface(NativeBridge(), "AndroidNative")
        tts = TextToSpeech(this, this)
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale("ro", "RO")
    }

    inner class NativeBridge {
        @JavascriptInterface fun speak(text: String) {
            runOnUiThread { tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "asistent-ai") }
        }
        @JavascriptInterface fun share(title: String, text: String) {
            runOnUiThread {
                try {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, title)
                        putExtra(Intent.EXTRA_TEXT, text)
                    }
                    startActivity(Intent.createChooser(send, title))
                } catch (e: Exception) {
                    webView.evaluateJavascript("setStatus('Partajarea nu a reușit. Încearcă butonul Copiază.')", null)
                }
            }
        }
        @JavascriptInterface fun openIn(pkg: String, label: String, text: String) {
            runOnUiThread {
                try {
                    val clipboard = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Asistent AI", text))
                } catch (e: Exception) { }
                val direct = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                    setPackage(pkg)
                }
                try {
                    startActivity(direct)
                    showStatus("Trimis către " + label + ". Dacă nu apare întrebarea, e copiată: lipește-o.")
                } catch (e: Exception) {
                    try {
                        val generic = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, text)
                        }
                        startActivity(Intent.createChooser(generic, label))
                        showStatus(label + " nu a primit textul direct. Întrebarea e copiată: deschide " + label + " și lipește-o.")
                    } catch (e2: Exception) {
                        showStatus("Nu am putut deschide " + label + ". Întrebarea e copiată.")
                    }
                }
            }
        }
        @JavascriptInterface fun startVoiceInput() {
            runOnUiThread {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) else startVoiceRecognizer()
            }
        }
    }

    private fun showStatus(msg: String) {
        webView.evaluateJavascript("setStatus('" + msg.replace("\\", "\\\\").replace("'", "\\'") + "')", null)
    }

    private fun startVoiceRecognizer() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ro-RO")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Vorbește...")
        }
        voiceLauncher.launch(intent)
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
