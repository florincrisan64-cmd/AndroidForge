ASISTENT AI - proiect Android

Baza este index.html-ul care functioneaza deja in Acode.
Proiectul adauga un WebView Android si bridge nativ pentru TTS si recunoastere vocala.
Cheia OpenRouter NU este inclusa in proiect.

Pentru compilare este necesar un mediu Android/Gradle (de ex. Android Studio pe PC).
